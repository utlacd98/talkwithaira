import { type NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json()

    // Get the last user message
    const lastMessage = messages[messages.length - 1]?.content || ""

    // Simple empathetic response logic (you can replace with AI SDK later)
    const responses = generateEmpatheticResponse(lastMessage)

    return NextResponse.json({ message: responses })
  } catch (error) {
    console.error("[v0] API error:", error)
    return NextResponse.json({ error: "Failed to process message" }, { status: 500 })
  }
}

function generateEmpatheticResponse(userMessage: string): string {
  const lowerMessage = userMessage.toLowerCase()

  // Detect emotional keywords and respond appropriately
  if (lowerMessage.includes("sad") || lowerMessage.includes("down") || lowerMessage.includes("depressed")) {
    return "I hear that you're feeling sad, and I want you to know that your feelings are completely valid. It's okay to not be okay sometimes. Would you like to talk more about what's weighing on your heart?"
  }

  if (lowerMessage.includes("anxious") || lowerMessage.includes("worried") || lowerMessage.includes("stress")) {
    return "I can sense the anxiety you're experiencing. Remember, it's natural to feel worried sometimes. Let's take a moment together - what specific thoughts are causing you the most concern right now?"
  }

  if (lowerMessage.includes("happy") || lowerMessage.includes("great") || lowerMessage.includes("excited")) {
    return "That's wonderful to hear! Your positive energy is beautiful. I'd love to hear more about what's bringing you joy today. Celebrating these moments is so important."
  }

  if (lowerMessage.includes("help") || lowerMessage.includes("support")) {
    return "I'm here to support you in any way I can. You've taken a brave step by reaching out. What would be most helpful for you right now?"
  }

  if (lowerMessage.includes("thank")) {
    return "You're very welcome. It's truly my purpose to be here for you. Remember, you're doing better than you think, and I'm always here whenever you need to talk."
  }

  // Default empathetic response
  return "Thank you for sharing that with me. I'm listening and I'm here for you. Could you tell me more about how you're feeling or what's on your mind?"
}
