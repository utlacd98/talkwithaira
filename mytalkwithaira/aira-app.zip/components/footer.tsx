import Link from "next/link"

export function Footer() {
  return (
    <footer className="border-t border-border bg-surface mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-full gradient-primary" />
              <span className="text-xl font-bold font-serif">Aira</span>
            </div>
            <p className="text-sm text-muted leading-relaxed max-w-md">
              Your AI companion that listens, reasons, and reflects with you. Discover emotional clarity and calm in
              every conversation.
            </p>
          </div>

          {/* Product */}
          <div>
            <h3 className="font-semibold mb-4">Product</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/about" className="text-sm text-muted hover:text-foreground transition-colors">
                  About Aira
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="text-sm text-muted hover:text-foreground transition-colors">
                  Pricing
                </Link>
              </li>
              <li>
                <Link href="/chat" className="text-sm text-muted hover:text-foreground transition-colors">
                  Try Chat
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-semibold mb-4">Legal</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/privacy" className="text-sm text-muted hover:text-foreground transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-sm text-muted hover:text-foreground transition-colors">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border">
          <p className="text-sm text-muted text-center">© {new Date().getFullYear()} Aira. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
